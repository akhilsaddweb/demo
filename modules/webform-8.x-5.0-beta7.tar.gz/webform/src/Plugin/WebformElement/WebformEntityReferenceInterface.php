<?php

namespace Drupal\webform\Plugin\WebformElement;

/**
 * Provides an 'entity_reference' interface used to detect entity reference elements.
 */
interface WebformEntityReferenceInterface {

}
