<?php

namespace Drupal\webform\Element;

/**
 * Provides a webform element for webform excluded elements.
 *
 * @FormElement("webform_excluded_elements")
 */
class WebformExcludedElements extends WebformExcludedBase {}
